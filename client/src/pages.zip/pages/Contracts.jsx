import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api.js";
import { Badge, Empty } from "../components/UI.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function Contracts() {
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    loadContracts();
  }, []);

  const loadContracts = async () => {
    try {
      const response = await api.get("/contracts");
      setContracts(
        Array.isArray(response.data) ? response.data : []
      );
    } catch (error) {
      console.error("Failed to load contracts:", error);
      setContracts([]);
    } finally {
      setLoading(false);
    }
  };

  const deleteContract = async (id) => {
    if (!window.confirm("Delete this contract?")) {
      return;
    }

    try {
      await api.delete(`/contracts/${id}`);
      loadContracts();
    } catch (error) {
      console.error("Failed to delete contract:", error);
    }
  };

  const canManage =
    user &&
    (user.role === "Admin" ||
      user.role === "Contract Manager");

  if (loading) {
    return (
      <div>
        <div className="page-head">
          <div>
            <h1>Contracts</h1>
            <p className="muted">
              Manage the complete contract lifecycle
            </p>
          </div>
        </div>

        <p>Loading contracts...</p>
      </div>
    );
  }

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>Contracts</h1>
          <p className="muted">
            Manage the complete contract lifecycle
          </p>
        </div>

        {canManage && (
          <Link className="btn primary" to="/contracts/new">
            + New Contract
          </Link>
        )}
      </div>

      {contracts.length === 0 ? (
        <Empty text="No contracts found" />
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Contract</th>
                <th>Vendor</th>
                <th>Status</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {contracts.map((contract) => (
                <tr key={contract._id}>
                  <td>
                    <b>
                      {contract.title ||
                        contract.contractName ||
                        "Untitled Contract"}
                    </b>
                  </td>

                  <td>
                    {contract.vendor?.vendorName ||
                      contract.vendorName ||
                      "N/A"}
                  </td>

                  <td>
                    <Badge>
                      {contract.status || "Draft"}
                    </Badge>
                  </td>

                  <td>
                    {contract.startDate
                      ? new Date(
                          contract.startDate
                        ).toLocaleDateString()
                      : "N/A"}
                  </td>

                  <td>
                    {contract.endDate
                      ? new Date(
                          contract.endDate
                        ).toLocaleDateString()
                      : "N/A"}
                  </td>

                  <td>
                    <div className="actions">
                      <Link
                        className="btn small"
                        to={`/contracts/${contract._id}`}
                      >
                        View
                      </Link>

                      {canManage && (
                        <Link
                          className="btn small"
                          to={`/contracts/${contract._id}/edit`}
                        >
                          Edit
                        </Link>
                      )}

                      {user?.role === "Admin" && (
                        <button
                          className="btn small danger"
                          onClick={() =>
                            deleteContract(contract._id)
                          }
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}